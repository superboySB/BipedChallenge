docker build -f docker/dev.Dockerfile -t tongverselite-dev .
