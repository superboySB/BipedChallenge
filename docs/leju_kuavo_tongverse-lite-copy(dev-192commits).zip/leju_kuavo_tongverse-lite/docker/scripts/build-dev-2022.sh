docker build -f docker/dev-2022.Dockerfile -t tongverselite-dev-2022 .
