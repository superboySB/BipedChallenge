docker save tongverselite-dev | gzip > tongverselite-dev_docker.tar.gz
