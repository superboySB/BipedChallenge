from tongverselite.sensor.sensor import Sensor
