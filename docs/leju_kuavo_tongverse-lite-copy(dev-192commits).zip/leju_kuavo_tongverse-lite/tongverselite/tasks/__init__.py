from tongverselite.tasks.base_task import BaseTask
from tongverselite.tasks.task_five import TaskFive
from tongverselite.tasks.task_four import TaskFour
from tongverselite.tasks.task_one import TaskOne
from tongverselite.tasks.task_six import TaskSix
from tongverselite.tasks.task_three import TaskThree
